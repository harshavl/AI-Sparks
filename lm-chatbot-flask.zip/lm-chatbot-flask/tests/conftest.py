"""
tests/conftest.py
Shared pytest fixtures — mocked LM client and Flask test client.
"""
import pytest
from unittest.mock import MagicMock, patch
from lm_chatbot.server import create_app
from lm_chatbot.config import Settings

TEST_SETTINGS = Settings(
    lm_account="testco",
    lm_bearer_token="test-token",
    lm_api_version="v3",
    flask_host="127.0.0.1",
    flask_port=8000,
    flask_env="development",
)

MOCK_DEVICES = {
    "total": 2,
    "items": [
        {"id": 101, "name": "Router_01", "displayName": "Core Router", "hostStatus": "alive"},
        {"id": 102, "name": "Switch_01", "displayName": "Edge Switch",  "hostStatus": "alive"},
    ],
}
MOCK_INSTANCES = {
    "total": 1,
    "items": [{"id": 5001, "name": "L3CVX-Guest", "displayName": "L3CVX VLAN", "dataSourceName": "SNMP_Interface"}],
}
MOCK_ALERTS = {
    "total": 1,
    "items": [{"id": "A1", "resourceTemplateName": "SNMP_Interface", "instanceName": "L3CVX-Guest",
               "severity": "warning", "message": "High utilisation"}],
}
MOCK_GROUPS     = {"total": 1, "items": [{"id": 10, "name": "Production", "fullPath": "/Production", "numOfHosts": 2}]}
MOCK_COLLECTORS = {"total": 1, "items": [{"id": 1,  "hostname": "col01", "status": "normal", "platform": "Linux"}]}
MOCK_DATASOURCES= {"total": 2, "items": [
    {"id": 1, "dataSourceName": "SNMP_Interface", "dataSourceType": "DS", "instanceNumber": 4},
    {"id": 2, "dataSourceName": "Ping",           "dataSourceType": "DS", "instanceNumber": 1},
]}


@pytest.fixture
def mock_lm():
    m = MagicMock()
    m.ping.return_value                    = {"total": 2, "items": []}
    m.search_devices.return_value          = MOCK_DEVICES
    m.get_device.return_value              = MOCK_DEVICES["items"][0]
    m.get_device_instances.return_value    = MOCK_INSTANCES
    m.search_instances_all_devices.return_value = {
        "devices_searched": 2, "devices_with_matches": 1,
        "matches": [{"device": MOCK_DEVICES["items"][0], "instances": MOCK_INSTANCES["items"]}],
    }
    m.get_device_groups.return_value       = MOCK_GROUPS
    m.get_alerts.return_value              = MOCK_ALERTS
    m.get_collectors.return_value          = MOCK_COLLECTORS
    m.get_device_datasources.return_value  = MOCK_DATASOURCES
    return m


@pytest.fixture
def client(mock_lm):
    """Flask test client with mocked LM client and settings."""
    with patch("lm_chatbot.server.get_settings", return_value=TEST_SETTINGS), \
         patch("lm_chatbot.server.LogicMonitorClient", return_value=mock_lm):
        app = create_app()
        app.config["TESTING"] = True
        with app.test_client() as c:
            yield c
