"""
tests/test_server.py
End-to-end tests for every Flask route (mocked LM client).
"""
import pytest
from lm_chatbot.lm_client import LMAPIError


# ── /api/health ───────────────────────────────────────────────────

def test_health_connected(client):
    r = client.get("/api/health")
    assert r.status_code == 200
    body = r.get_json()
    assert body["status"] == "ok"
    assert body["lm_connected"] is True
    assert body["lm_account"] == "testco"
    assert body["total_devices"] == 2


def test_health_lm_down(client, mock_lm):
    mock_lm.ping.side_effect = LMAPIError(401, "Unauthorized")
    r = client.get("/api/health")
    assert r.status_code == 200
    body = r.get_json()
    assert body["status"] == "degraded"
    assert body["lm_connected"] is False


# ── /api/lm/devices ───────────────────────────────────────────────

def test_list_devices(client):
    r = client.get("/api/lm/devices")
    assert r.status_code == 200
    body = r.get_json()
    assert body["total"] == 2
    assert body["items"][0]["name"] == "Router_01"


def test_search_devices_passes_filter(client, mock_lm):
    client.get('/api/lm/devices?filter=name:"Router_01"')
    mock_lm.search_devices.assert_called_once()
    assert "Router_01" in mock_lm.search_devices.call_args.kwargs["filter"]


def test_get_device_by_id(client):
    r = client.get("/api/lm/devices/101")
    assert r.status_code == 200
    assert r.get_json()["id"] == 101


def test_devices_lm_error_propagates(client, mock_lm):
    mock_lm.search_devices.side_effect = LMAPIError(403, "Forbidden")
    r = client.get("/api/lm/devices")
    assert r.status_code == 403


def test_size_clamped_to_max(client, mock_lm):
    client.get("/api/lm/devices?size=99999")
    # should be clamped to 1000, not crash
    _, kwargs = mock_lm.search_devices.call_args
    assert kwargs["size"] <= 1000


# ── /api/lm/devices/<id>/instances ───────────────────────────────

def test_get_instances(client):
    r = client.get("/api/lm/devices/101/instances")
    assert r.status_code == 200
    body = r.get_json()
    assert body["items"][0]["name"] == "L3CVX-Guest"


def test_get_instances_with_filter(client, mock_lm):
    client.get('/api/lm/devices/101/instances?filter=name~"L3CVX"')
    mock_lm.get_device_instances.assert_called_once()


# ── /api/lm/instances/search ─────────────────────────────────────

def test_global_instance_search(client):
    r = client.get('/api/lm/instances/search?instance_filter=name~"L3CVX-Guest"')
    assert r.status_code == 200
    body = r.get_json()
    assert body["devices_searched"] == 2
    assert body["devices_with_matches"] == 1


def test_global_search_missing_filter(client):
    r = client.get("/api/lm/instances/search")
    assert r.status_code == 400


# ── /api/lm/alerts ───────────────────────────────────────────────

def test_get_alerts(client):
    r = client.get("/api/lm/alerts")
    assert r.status_code == 200
    body = r.get_json()
    assert body["items"][0]["severity"] == "warning"


# ── /api/lm/groups ───────────────────────────────────────────────

def test_get_groups(client):
    r = client.get("/api/lm/groups")
    assert r.status_code == 200
    assert r.get_json()["items"][0]["name"] == "Production"


# ── /api/lm/collectors ───────────────────────────────────────────

def test_get_collectors(client):
    r = client.get("/api/lm/collectors")
    assert r.status_code == 200
    assert r.get_json()["items"][0]["hostname"] == "col01"


# ── /api/lm/devices/<id>/datasources ─────────────────────────────

def test_get_datasources(client):
    r = client.get("/api/lm/devices/101/datasources")
    assert r.status_code == 200
    body = r.get_json()
    assert len(body["items"]) == 2
    assert body["items"][0]["dataSourceName"] == "SNMP_Interface"


# ── UI ────────────────────────────────────────────────────────────

def test_index_serves_html(client):
    r = client.get("/")
    assert r.status_code == 200
    assert b"LogicMonitor" in r.data
    assert b"text/html" in r.content_type.encode()
