"""
tests/test_lm_client.py
Unit tests for LogicMonitorClient.
Uses the 'responses' library to mock the 'requests' HTTP calls.
"""
import pytest
import responses as rsp
from lm_chatbot.config import Settings
from lm_chatbot.lm_client import LogicMonitorClient, LMAPIError

BASE = "https://testco.logicmonitor.com/santaba/rest"

SETTINGS = Settings(
    lm_account="testco",
    lm_bearer_token="test-token",
    lm_api_version="v3",
    flask_host="127.0.0.1",
    flask_port=8000,
    flask_env="development",
)


@pytest.fixture
def lm():
    client = LogicMonitorClient(SETTINGS)
    yield client
    client.close()


# ── ping ─────────────────────────────────────────────────────────

@rsp.activate
def test_ping_success(lm):
    rsp.add(rsp.GET, f"{BASE}/device/devices",
            json={"total": 5, "items": []}, status=200)
    result = lm.ping()
    assert result["total"] == 5


# ── search_devices ────────────────────────────────────────────────

@rsp.activate
def test_search_devices(lm):
    rsp.add(rsp.GET, f"{BASE}/device/devices",
            json={"total": 1, "items": [{"id": 101, "name": "Router_01", "hostStatus": "alive"}]},
            status=200)
    result = lm.search_devices(filter='name:"Router_01"')
    assert result["items"][0]["name"] == "Router_01"


# ── get_device ────────────────────────────────────────────────────

@rsp.activate
def test_get_device(lm):
    rsp.add(rsp.GET, f"{BASE}/device/devices/101",
            json={"id": 101, "name": "Router_01"}, status=200)
    result = lm.get_device(101)
    assert result["id"] == 101


# ── 401 raises LMAPIError ────────────────────────────────────────

@rsp.activate
def test_lm_api_error_401(lm):
    rsp.add(rsp.GET, f"{BASE}/device/devices",
            body="Unauthorized", status=401)
    with pytest.raises(LMAPIError) as exc:
        lm.search_devices()
    assert exc.value.status == 401


# ── instances ─────────────────────────────────────────────────────

@rsp.activate
def test_get_device_instances(lm):
    rsp.add(rsp.GET, f"{BASE}/device/devices/101/instances",
            json={"total": 1, "items": [{"id": 5001, "name": "L3CVX-Guest", "dataSourceName": "SNMP_Interface"}]},
            status=200)
    result = lm.get_device_instances(101, filter='name~"L3CVX"')
    assert result["items"][0]["name"] == "L3CVX-Guest"


# ── alerts ────────────────────────────────────────────────────────

@rsp.activate
def test_get_alerts(lm):
    rsp.add(rsp.GET, f"{BASE}/alert/alerts",
            json={"total": 1, "items": [{"id": "A1", "severity": "critical"}]},
            status=200)
    result = lm.get_alerts()
    assert result["items"][0]["severity"] == "critical"


# ── collectors ────────────────────────────────────────────────────

@rsp.activate
def test_get_collectors(lm):
    rsp.add(rsp.GET, f"{BASE}/setting/collector/collectors",
            json={"total": 1, "items": [{"id": 1, "hostname": "col01", "status": "normal"}]},
            status=200)
    result = lm.get_collectors()
    assert result["items"][0]["status"] == "normal"


# ── connection error ──────────────────────────────────────────────

@rsp.activate
def test_connection_error_raises(lm):
    import requests
    rsp.add(rsp.GET, f"{BASE}/device/devices",
            body=requests.exceptions.ConnectionError("refused"))
    with pytest.raises(LMAPIError) as exc:
        lm.search_devices()
    assert "Connection error" in str(exc.value)


# ── global instance search ────────────────────────────────────────

@rsp.activate
def test_search_instances_all_devices(lm):
    rsp.add(rsp.GET, f"{BASE}/device/devices",
            json={"total": 1, "items": [{"id": 101, "name": "Router_01"}]}, status=200)
    rsp.add(rsp.GET, f"{BASE}/device/devices/101/instances",
            json={"total": 1, "items": [{"id": 5001, "name": "L3CVX-Guest", "dataSourceName": "SNMP_Interface"}]},
            status=200)
    result = lm.search_instances_all_devices('name~"L3CVX-Guest"')
    assert result["devices_with_matches"] == 1
    assert result["matches"][0]["device"]["name"] == "Router_01"
