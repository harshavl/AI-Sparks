"""LogicMonitor Chatbot — Flask + requests edition."""
__version__ = "1.0.0"
