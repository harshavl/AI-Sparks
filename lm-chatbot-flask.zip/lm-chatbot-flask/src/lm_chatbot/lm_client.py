"""
lm_client.py
LogicMonitor REST API client using the 'requests' library.

All methods return parsed JSON dicts.
LMAPIError is raised on any non-2xx response.
"""
from __future__ import annotations

import logging
from typing import Any

import requests
from requests import Session
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from lm_chatbot.config import Settings

log = logging.getLogger(__name__)


class LMAPIError(Exception):
    """Raised on non-2xx LogicMonitor API responses."""
    def __init__(self, status: int, body: str) -> None:
        self.status = status
        self.body   = body
        super().__init__(f"LM API {status}: {body[:300]}")


class LogicMonitorClient:
    """
    Synchronous LogicMonitor REST API client built on 'requests'.

    Uses a persistent Session with:
      - connection pooling (keep-alive)
      - automatic retries on transient network errors
      - 30-second timeout on every call
    """

    def __init__(self, settings: Settings) -> None:
        self._base   = settings.lm_base_url
        self._session = Session()

        # ── auth headers on every request ──────────────────────
        self._session.headers.update({
            "Authorization": f"Bearer {settings.lm_bearer_token}",
            "Content-Type":  "application/json",
            "X-Version":     settings.lm_version_header,
        })

        # ── retry on connection errors and 5xx ─────────────────
        retry = Retry(
            total=3,
            backoff_factor=0.5,
            status_forcelist=[500, 502, 503, 504],
            allowed_methods=["GET"],
        )
        adapter = HTTPAdapter(
            max_retries=retry,
            pool_connections=10,
            pool_maxsize=20,
        )
        self._session.mount("https://", adapter)
        self._session.mount("http://",  adapter)

    # ── internal ───────────────────────────────────────────────

    def _get(self, path: str, params: dict[str, Any] | None = None) -> dict:
        """Make a GET request; raise LMAPIError on non-2xx."""
        clean = {k: v for k, v in (params or {}).items() if v is not None}
        url   = self._base + path
        log.debug("LM GET %s params=%s", path, clean)

        try:
            resp = self._session.get(url, params=clean, timeout=30)
        except requests.exceptions.ConnectionError as exc:
            raise LMAPIError(0, f"Connection error: {exc}") from exc
        except requests.exceptions.Timeout as exc:
            raise LMAPIError(0, f"Request timed out: {exc}") from exc
        except requests.exceptions.RequestException as exc:
            raise LMAPIError(0, f"Request failed: {exc}") from exc

        if not resp.ok:
            log.warning("LM API error %s %s → %s", resp.status_code, path, resp.text[:200])
            raise LMAPIError(resp.status_code, resp.text)

        log.debug("LM OK %s %s", resp.status_code, path)
        return resp.json()

    def close(self) -> None:
        self._session.close()

    # ── public API methods ─────────────────────────────────────

    def ping(self) -> dict:
        """Verify connectivity — fetches 1 device."""
        return self._get("/device/devices", {"size": 1, "fields": "id,name"})

    def search_devices(
        self,
        filter: str | None = None,
        size: int = 50,
        fields: str = "id,name,displayName,hostStatus,hostGroupIds",
    ) -> dict:
        return self._get("/device/devices", {
            "filter": filter, "size": size, "fields": fields,
        })

    def get_device(self, device_id: int) -> dict:
        return self._get(f"/device/devices/{device_id}")

    def get_device_instances(
        self,
        device_id: int,
        filter: str | None = None,
        size: int = 100,
        fields: str = "id,name,displayName,dataSourceName",
    ) -> dict:
        return self._get(f"/device/devices/{device_id}/instances", {
            "filter": filter, "size": size, "fields": fields,
        })

    def search_instances_all_devices(
        self,
        instance_filter: str,
        device_filter: str | None = None,
        max_devices: int = 30,
    ) -> dict:
        """Fan-out: search instance across multiple devices (synchronous loop)."""
        devs = self.search_devices(
            filter=device_filter, size=max_devices, fields="id,name,displayName"
        ).get("items", [])

        matches = []
        for dev in devs:
            try:
                r = self.get_device_instances(dev["id"], filter=instance_filter)
                if r.get("items"):
                    matches.append({"device": dev, "instances": r["items"]})
            except LMAPIError:
                pass   # skip unreachable devices silently

        return {
            "devices_searched":     len(devs),
            "devices_with_matches": len(matches),
            "matches":              matches,
        }

    def get_device_groups(
        self,
        filter: str | None = None,
        size: int = 50,
    ) -> dict:
        return self._get("/device/groups", {
            "filter": filter, "size": size,
            "fields": "id,name,fullPath,numOfHosts",
        })

    def get_alerts(
        self,
        filter: str | None = None,
        size: int = 30,
    ) -> dict:
        return self._get("/alert/alerts", {
            "filter": filter, "size": size,
            "fields": "id,resourceTemplateName,instanceName,severity,startEpoch,message,resourceId",
        })

    def get_collectors(self, size: int = 20) -> dict:
        return self._get("/setting/collector/collectors", {
            "size": size,
            "fields": "id,hostname,status,description,platform",
        })

    def get_device_datasources(self, device_id: int, size: int = 50) -> dict:
        return self._get(f"/device/devices/{device_id}/devicedatasources", {
            "size": size,
            "fields": "id,dataSourceName,dataSourceType,instanceNumber",
        })
