"""
config.py
Loads all settings from .env (or environment variables).
Call get_settings() anywhere — returns a cached singleton.
"""
import os
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from dotenv import load_dotenv

# Walk up from this file to find .env
for _p in [Path(__file__).parent, Path(__file__).parent.parent,
           Path(__file__).parent.parent.parent]:
    if (_p / ".env").exists():
        load_dotenv(_p / ".env")
        break


@dataclass
class Settings:
    lm_account: str
    lm_bearer_token: str
    lm_api_version: str
    flask_host: str
    flask_port: int
    flask_env: str

    @property
    def lm_base_url(self) -> str:
        return f"https://{self.lm_account}.logicmonitor.com/santaba/rest"

    @property
    def lm_version_header(self) -> str:
        return "3" if self.lm_api_version == "v3" else "2"

    @property
    def is_production(self) -> bool:
        return self.flask_env.lower() == "production"

    def validate(self) -> None:
        """Raise ValueError if required vars are missing."""
        missing = [k for k, v in [
            ("LM_ACCOUNT", self.lm_account),
            ("LM_BEARER_TOKEN", self.lm_bearer_token),
        ] if not v]
        if missing:
            raise ValueError(
                f"Missing required environment variables: {', '.join(missing)}\n"
                "Copy .env.example → .env and fill in your credentials."
            )


@lru_cache
def get_settings() -> Settings:
    return Settings(
        lm_account      = os.getenv("LM_ACCOUNT", ""),
        lm_bearer_token = os.getenv("LM_BEARER_TOKEN", ""),
        lm_api_version  = os.getenv("LM_API_VERSION", "v3"),
        flask_host      = os.getenv("FLASK_HOST", "0.0.0.0"),
        flask_port      = int(os.getenv("FLASK_PORT", "8000")),
        flask_env       = os.getenv("FLASK_ENV", "development"),
    )
