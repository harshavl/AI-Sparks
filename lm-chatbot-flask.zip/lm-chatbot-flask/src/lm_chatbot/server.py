"""
server.py
Flask application — all routes, startup validation, and entry point.

Routes
------
GET  /                              → serves chatbot.html (the UI)
GET  /api/health                    → liveness + LM connectivity
GET  /api/lm/devices                → search / list devices
GET  /api/lm/devices/<id>           → single device detail
GET  /api/lm/devices/<id>/instances → instances on a device
GET  /api/lm/instances/search       → instances across all devices
GET  /api/lm/devices/<id>/datasources
GET  /api/lm/groups
GET  /api/lm/alerts
GET  /api/lm/collectors
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory, abort

from lm_chatbot import __version__
from lm_chatbot.config import get_settings
from lm_chatbot.lm_client import LogicMonitorClient, LMAPIError

# ── logging setup ─────────────────────────────────────────────────
logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger(__name__)

STATIC_DIR = Path(__file__).parent / "static"


# ── app factory ───────────────────────────────────────────────────

def create_app() -> Flask:
    settings = get_settings()
    logging.getLogger().setLevel(settings.flask_env == "development" and "DEBUG" or "INFO")

    app = Flask(__name__, static_folder=str(STATIC_DIR))

    # Shared LM client (connection-pooled session)
    lm = LogicMonitorClient(settings)

    # ── CORS headers (needed for Chrome extension) ────────────
    @app.after_request
    def add_cors(response):
        response.headers["Access-Control-Allow-Origin"]  = "*"
        response.headers["Access-Control-Allow-Methods"] = "GET, OPTIONS"
        response.headers["Access-Control-Allow-Headers"] = "Content-Type"
        return response

    # ── error helper ──────────────────────────────────────────
    def lm_error(exc: LMAPIError):
        status = exc.status if exc.status else 502
        return jsonify({"error": exc.body[:400]}), status

    # ── UI ────────────────────────────────────────────────────
    @app.get("/")
    def index():
        return send_from_directory(str(STATIC_DIR), "chatbot.html")

    # ── health ────────────────────────────────────────────────
    @app.get("/api/health")
    def health():
        connected = False
        try:
            data = lm.ping()
            connected = True
            total = data.get("total", "?")
        except LMAPIError:
            total = 0

        return jsonify({
            "status":       "ok" if connected else "degraded",
            "lm_account":   settings.lm_account,
            "lm_connected": connected,
            "total_devices": total,
            "version":      __version__,
        })

    # ── devices ───────────────────────────────────────────────
    @app.get("/api/lm/devices")
    def list_devices():
        try:
            return jsonify(lm.search_devices(
                filter = request.args.get("filter"),
                size   = _int(request.args.get("size", 50), 1, 1000),
                fields = request.args.get("fields", "id,name,displayName,hostStatus,hostGroupIds"),
            ))
        except LMAPIError as e:
            return lm_error(e)

    @app.get("/api/lm/devices/<int:device_id>")
    def get_device(device_id: int):
        try:
            return jsonify(lm.get_device(device_id))
        except LMAPIError as e:
            return lm_error(e)

    # ── instances ─────────────────────────────────────────────
    @app.get("/api/lm/devices/<int:device_id>/instances")
    def get_instances(device_id: int):
        try:
            return jsonify(lm.get_device_instances(
                device_id,
                filter = request.args.get("filter"),
                size   = _int(request.args.get("size", 100), 1, 1000),
            ))
        except LMAPIError as e:
            return lm_error(e)

    @app.get("/api/lm/instances/search")
    def search_instances():
        instance_filter = request.args.get("instance_filter")
        if not instance_filter:
            return jsonify({"error": "instance_filter is required"}), 400
        try:
            return jsonify(lm.search_instances_all_devices(
                instance_filter = instance_filter,
                device_filter   = request.args.get("device_filter"),
                max_devices     = _int(request.args.get("max_devices", 30), 1, 100),
            ))
        except LMAPIError as e:
            return lm_error(e)

    # ── datasources ───────────────────────────────────────────
    @app.get("/api/lm/devices/<int:device_id>/datasources")
    def get_datasources(device_id: int):
        try:
            return jsonify(lm.get_device_datasources(
                device_id,
                size = _int(request.args.get("size", 50), 1, 1000),
            ))
        except LMAPIError as e:
            return lm_error(e)

    # ── groups ────────────────────────────────────────────────
    @app.get("/api/lm/groups")
    def get_groups():
        try:
            return jsonify(lm.get_device_groups(
                filter = request.args.get("filter"),
                size   = _int(request.args.get("size", 50), 1, 1000),
            ))
        except LMAPIError as e:
            return lm_error(e)

    # ── alerts ────────────────────────────────────────────────
    @app.get("/api/lm/alerts")
    def get_alerts():
        try:
            return jsonify(lm.get_alerts(
                filter = request.args.get("filter"),
                size   = _int(request.args.get("size", 30), 1, 1000),
            ))
        except LMAPIError as e:
            return lm_error(e)

    # ── collectors ────────────────────────────────────────────
    @app.get("/api/lm/collectors")
    def get_collectors():
        try:
            return jsonify(lm.get_collectors(
                size = _int(request.args.get("size", 20), 1, 100),
            ))
        except LMAPIError as e:
            return lm_error(e)

    return app


# ── int param helper ──────────────────────────────────────────────

def _int(value, min_val: int, max_val: int) -> int:
    """Parse query-param int, clamp to [min_val, max_val]."""
    try:
        v = int(value)
    except (TypeError, ValueError):
        v = min_val
    return max(min_val, min(max_val, v))


# ── entry point ───────────────────────────────────────────────────

def run() -> None:
    """Called by `poetry run lm-server`."""
    settings = get_settings()

    try:
        settings.validate()
    except ValueError as exc:
        print(f"\n[ERROR] {exc}\n")
        sys.exit(1)

    # Startup connectivity check
    lm = LogicMonitorClient(settings)
    try:
        data = lm.ping()
        print(f"[OK] Connected to {settings.lm_account}.logicmonitor.com "
              f"— {data.get('total', '?')} devices found")
    except LMAPIError as exc:
        print(f"[WARN] LogicMonitor connection failed: {exc}")
        print("       Check LM_ACCOUNT and LM_BEARER_TOKEN in .env")
    lm.close()

    app = create_app()
    print(f"[OK] Starting server at http://{settings.flask_host}:{settings.flask_port}")
    print(f"     Open http://localhost:{settings.flask_port} in your browser\n")

    app.run(
        host  = settings.flask_host,
        port  = settings.flask_port,
        debug = not settings.is_production,
        use_reloader = not settings.is_production,
    )


if __name__ == "__main__":
    run()
