(function(){
  if(document.getElementById('lm-chat-bubble'))return;
  const SERVER='http://localhost:8000';
  let open=false;

  const bubble=document.createElement('button');
  bubble.id='lm-chat-bubble';bubble.innerHTML='LM';bubble.title='Open LM Chatbot';
  document.body.appendChild(bubble);

  const panel=document.createElement('div');panel.id='lm-chat-panel';
  const close=document.createElement('button');close.id='lm-chat-close';close.innerHTML='✕';close.title='Close';
  const iframe=document.createElement('iframe');iframe.id='lm-chat-iframe';iframe.src=SERVER+'/';iframe.title='LM Chatbot';
  panel.appendChild(close);panel.appendChild(iframe);
  document.body.appendChild(panel);

  function openPanel(){open=true;panel.classList.add('open');bubble.classList.add('open');bubble.innerHTML='✕';}
  function closePanel(){open=false;panel.classList.remove('open');bubble.classList.remove('open');bubble.innerHTML='LM';}

  bubble.addEventListener('click',()=>open?closePanel():openPanel());
  close.addEventListener('click',closePanel);
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&open)closePanel();});
})();
