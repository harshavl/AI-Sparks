# LogicMonitor Chatbot — Flask + requests edition

No FastAPI. No Node.js. No npm. Just Python.

```
Browser  →  Flask /api/lm/*  →  LogicMonitor REST API
               ↑
        Bearer token lives here only.
        Uses Python 'requests' library.
```

## Project structure

```
lm-chatbot/
├── pyproject.toml                  Poetry config
├── Makefile                        install / run / test
├── .env.example                    → copy to .env
│
├── src/lm_chatbot/
│   ├── __init__.py
│   ├── config.py                   reads .env, Settings dataclass
│   ├── lm_client.py                requests-based LM API client
│   ├── server.py                   Flask app + all routes + entry point
│   └── static/
│       └── chatbot.html            button UI (pure browser JS, zero npm)
│
├── tests/
│   ├── conftest.py                 fixtures + mocked LM client
│   ├── test_server.py              Flask route tests (20 cases)
│   └── test_lm_client.py          LM client tests (responses mocks)
│
└── extension/
    ├── manifest.json               Chrome extension manifest v3
    ├── content.js                  floating bubble on LM pages
    └── bubble.css                  panel styles
```

## Quick start — 4 commands

```bash
# 1. Install
make install

# 2. Create .env
make setup
# → edit .env: set LM_ACCOUNT and LM_BEARER_TOKEN

# 3. Run
make run
# → http://localhost:8000

# 4. Test (no LM account needed — all mocked)
make test
```

## Dependencies — nothing exotic

| Package | Purpose |
|---------|---------|
| `flask` | Web framework + serving the UI |
| `requests` | HTTP calls to LogicMonitor API |
| `python-dotenv` | Reads `.env` file |
| `pytest` + `responses` | Testing (dev only) |

## Getting a LogicMonitor Bearer Token

1. Log in to your LM portal
2. Go to **Settings → API Tokens**
3. Click **Add Token** → select type **Bearer**
4. Copy the value into `.env` as `LM_BEARER_TOKEN`

## Chrome Extension

1. Open `chrome://extensions`
2. Enable **Developer mode**
3. Click **Load unpacked** → select `extension/` folder
4. Open any `*.logicmonitor.com` page → click the **LM** bubble

## Environment variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `LM_ACCOUNT` | ✓ | — | Portal subdomain |
| `LM_BEARER_TOKEN` | ✓ | — | Bearer API token |
| `LM_API_VERSION` | | `v3` | `v3` or `v2` |
| `FLASK_HOST` | | `0.0.0.0` | Bind host |
| `FLASK_PORT` | | `8000` | Port |
| `FLASK_ENV` | | `development` | `development` or `production` |
