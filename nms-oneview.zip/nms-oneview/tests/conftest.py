import pytest
from unittest.mock import MagicMock, patch
from nms_oneview.server import create_app
from nms_oneview.config import Settings, LMConfig, AlgoSecConfig, KentikConfig

SETTINGS = Settings(
    flask_host="127.0.0.1", flask_port=8000, flask_env="development",
    lm=LMConfig(enabled=True, account="testco", bearer_token="tok", api_version="v3"),
    algosec=AlgoSecConfig(enabled=True, host="https://as.test", username="admin", password="pw"),
    kentik=KentikConfig(enabled=True, email="me@test.com", api_token="kttok"),
)

def _mock_lm():
    m=MagicMock()
    m.ping.return_value={"total":2,"items":[]}
    m.search_devices.return_value={"total":2,"items":[
        {"id":101,"name":"Router_01","displayName":"Core Router","hostStatus":"alive"},
        {"id":102,"name":"Switch_01","displayName":"Edge Switch","hostStatus":"alive"},
    ]}
    m.get_device.return_value={"id":101,"name":"Router_01","hostStatus":"alive","description":""}
    m.get_device_instances.return_value={"total":1,"items":[{"id":5001,"name":"L3CVX-Guest","dataSourceName":"SNMP_Interface"}]}
    m.search_instances_all_devices.return_value={"devices_searched":2,"devices_with_matches":1,"matches":[]}
    m.get_device_groups.return_value={"total":1,"items":[{"id":10,"name":"Prod","fullPath":"/Prod","numOfHosts":2}]}
    m.get_alerts.return_value={"total":1,"items":[{"id":"A1","severity":"warning","resourceTemplateName":"Ping","instanceName":"x","message":"high"}]}
    m.get_collectors.return_value={"total":1,"items":[{"id":1,"hostname":"col01","status":"normal","platform":"Linux"}]}
    m.get_device_datasources.return_value={"total":1,"items":[{"id":1,"dataSourceName":"SNMP","dataSourceType":"DS","instanceNumber":2}]}
    return m

def _mock_algosec():
    m=MagicMock()
    m.ping.return_value={"network_objects":[]}
    m.get_devices.return_value={"devices":[{"id":"fw1","name":"fw-prod","type":"Cisco","ip":"10.0.0.1"}]}
    m.get_network_objects.return_value={"network_objects":[{"name":"DMZ","type":"network","value":"10.1.0.0/24"}]}
    m.search_firewall_rules.return_value={"rules":[{"name":"Allow-HTTPS","source":"any","destination":"10.0.0.0/8","service":"HTTPS","action":"allow"}]}
    m.simulate_traffic.return_value={"status":"allowed","result":"ALLOW"}
    m.get_change_requests.return_value={"change_requests":[{"id":"CR001","subject":"Add rule","status":"open","requestor":"admin"}]}
    return m

def _mock_kentik():
    m=MagicMock()
    m.ping.return_value={"devices":[]}
    m.get_devices.return_value={"devices":[{"id":1,"name":"router-core","device_type":"router","sending_ips":["10.0.0.1"]}]}
    m.get_interfaces.return_value={"interfaces":[{"id":1,"interface_description":"GE0/0","interface_ip":"10.0.0.2","interface_speed":"1000000000"}]}
    m.get_alerts.return_value={"alerts":[{"severity":"warning","alert_name":"High traffic","policy_name":"BPS","description":"exceeded"}]}
    m.get_top_flows.return_value={"results":[]}
    m.get_sites.return_value={"sites":[{"id":1,"site_name":"HQ","latitude":"51.5","longitude":"-0.1"}]}
    m.get_plans.return_value={"plans":[{"id":1,"name":"Enterprise","description":"Full","max_devices":500}]}
    return m


@pytest.fixture
def mock_lm(): return _mock_lm()
@pytest.fixture
def mock_as(): return _mock_algosec()
@pytest.fixture
def mock_kt(): return _mock_kentik()

@pytest.fixture
def client(mock_lm, mock_as, mock_kt):
    with patch("nms_oneview.server.get_settings", return_value=SETTINGS), \
         patch("nms_oneview.server.LogicMonitorClient", return_value=mock_lm), \
         patch("nms_oneview.server.AlgoSecClient",      return_value=mock_as), \
         patch("nms_oneview.server.KentikClient",       return_value=mock_kt):
        app = create_app()
        app.config["TESTING"] = True
        with app.test_client() as c:
            yield c
