"""tests/test_server.py — all routes for all three tools."""
from nms_oneview.clients.base import ToolAPIError

# ── health ──────────────────────────────────────────────────────
def test_health_all_connected(client):
    r=client.get("/api/health")
    assert r.status_code==200
    b=r.get_json()
    assert b["status"]=="ok"
    assert "lm" in b["tools"]
    assert "algosec" in b["tools"]
    assert "kentik" in b["tools"]

def test_health_tool_down(client,mock_lm):
    mock_lm.ping.side_effect=ToolAPIError(401,"Unauthorized","LM")
    r=client.get("/api/health")
    assert r.status_code==200
    assert r.get_json()["tools"]["lm"]["status"]=="error"

def test_index_html(client):
    r=client.get("/")
    assert r.status_code==200
    assert b"NMS OneView" in r.data

# ── LogicMonitor ─────────────────────────────────────────────────
def test_lm_list_devices(client):
    r=client.get("/api/lm/devices")
    assert r.status_code==200
    assert r.get_json()["total"]==2

def test_lm_get_device(client):
    r=client.get("/api/lm/devices/101")
    assert r.status_code==200
    assert r.get_json()["id"]==101

def test_lm_instances(client):
    r=client.get("/api/lm/devices/101/instances")
    assert r.status_code==200
    assert r.get_json()["items"][0]["name"]=="L3CVX-Guest"

def test_lm_instance_search(client):
    r=client.get('/api/lm/instances/search?instance_filter=name~"L3CVX"')
    assert r.status_code==200

def test_lm_instance_search_missing_param(client):
    r=client.get("/api/lm/instances/search")
    assert r.status_code==400

def test_lm_alerts(client):
    r=client.get("/api/lm/alerts")
    assert r.status_code==200
    assert r.get_json()["items"][0]["severity"]=="warning"

def test_lm_groups(client):
    r=client.get("/api/lm/groups")
    assert r.status_code==200
    assert r.get_json()["items"][0]["name"]=="Prod"

def test_lm_collectors(client):
    r=client.get("/api/lm/collectors")
    assert r.status_code==200
    assert r.get_json()["items"][0]["status"]=="normal"

def test_lm_error_propagates(client,mock_lm):
    mock_lm.search_devices.side_effect=ToolAPIError(403,"Forbidden","LM")
    r=client.get("/api/lm/devices")
    assert r.status_code==403

# ── AlgoSec ──────────────────────────────────────────────────────
def test_as_devices(client):
    r=client.get("/api/algosec/devices")
    assert r.status_code==200
    assert r.get_json()["devices"][0]["name"]=="fw-prod"

def test_as_rules(client):
    r=client.get("/api/algosec/rules?src=10.0.0.1")
    assert r.status_code==200
    assert r.get_json()["rules"][0]["action"]=="allow"

def test_as_simulate(client):
    r=client.get("/api/algosec/simulate?src=10.0.0.1&dst=192.168.1.1")
    assert r.status_code==200
    assert r.get_json()["status"]=="allowed"

def test_as_simulate_missing_params(client):
    r=client.get("/api/algosec/simulate?src=10.0.0.1")
    assert r.status_code==400

def test_as_network_objects(client):
    r=client.get("/api/algosec/network_objects?search=DMZ")
    assert r.status_code==200
    assert r.get_json()["network_objects"][0]["name"]=="DMZ"

def test_as_change_requests(client):
    r=client.get("/api/algosec/change_requests")
    assert r.status_code==200
    assert r.get_json()["change_requests"][0]["id"]=="CR001"

# ── Kentik ───────────────────────────────────────────────────────
def test_kt_devices(client):
    r=client.get("/api/kentik/devices")
    assert r.status_code==200
    assert r.get_json()["devices"][0]["name"]=="router-core"

def test_kt_interfaces(client):
    r=client.get("/api/kentik/devices/1/interfaces")
    assert r.status_code==200
    assert r.get_json()["interfaces"][0]["interface_description"]=="GE0/0"

def test_kt_alerts(client):
    r=client.get("/api/kentik/alerts")
    assert r.status_code==200
    assert r.get_json()["alerts"][0]["severity"]=="warning"

def test_kt_sites(client):
    r=client.get("/api/kentik/sites")
    assert r.status_code==200
    assert r.get_json()["sites"][0]["site_name"]=="HQ"

def test_kt_plans(client):
    r=client.get("/api/kentik/plans")
    assert r.status_code==200
    assert r.get_json()["plans"][0]["name"]=="Enterprise"

def test_kt_top_flows(client):
    r=client.get("/api/kentik/top_flows")
    assert r.status_code==200
