"""
server.py
NMS OneView — Flask server exposing all tool APIs as /api/<tool>/...

Route map
─────────
GET /                                     → chatbot UI
GET /api/health                           → status of all tools

GET /api/lm/devices                       → LM: search devices
GET /api/lm/devices/<id>                  → LM: single device
GET /api/lm/devices/<id>/instances        → LM: instances
GET /api/lm/instances/search              → LM: global instance search
GET /api/lm/devices/<id>/datasources      → LM: datasources
GET /api/lm/groups                        → LM: device groups
GET /api/lm/alerts                        → LM: active alerts
GET /api/lm/collectors                    → LM: collectors

GET /api/algosec/devices                  → AS: firewalls list
GET /api/algosec/network_objects          → AS: network objects
GET /api/algosec/rules                    → AS: firewall rules
GET /api/algosec/simulate                 → AS: traffic simulation
GET /api/algosec/change_requests          → AS: change requests

GET /api/kentik/devices                   → KT: routers/switches
GET /api/kentik/devices/<id>/interfaces   → KT: interfaces
GET /api/kentik/alerts                    → KT: active alerts
GET /api/kentik/top_flows                 → KT: top talkers
GET /api/kentik/sites                     → KT: sites
GET /api/kentik/plans                     → KT: capacity plans
"""
from __future__ import annotations

import sys
import logging
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory

from nms_oneview import __version__
from nms_oneview.config import get_settings
from nms_oneview.clients.base import ToolAPIError
from nms_oneview.clients.logicmonitor import LogicMonitorClient
from nms_oneview.clients.algosec import AlgoSecClient
from nms_oneview.clients.kentik import KentikClient

logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger(__name__)

STATIC_DIR = Path(__file__).parent / "static"


# ── app factory ───────────────────────────────────────────────────

def create_app() -> Flask:
    cfg = get_settings()
    logging.getLogger().setLevel("DEBUG" if cfg.flask_env == "development" else "INFO")

    app = Flask(__name__, static_folder=str(STATIC_DIR))

    # ── instantiate tool clients (only if configured) ─────────
    lm      = LogicMonitorClient(cfg.lm)      if cfg.lm.is_ready      else None
    algosec = AlgoSecClient(cfg.algosec)       if cfg.algosec.is_ready  else None
    kentik  = KentikClient(cfg.kentik)         if cfg.kentik.is_ready   else None

    # ── CORS ──────────────────────────────────────────────────
    @app.after_request
    def cors(resp):
        resp.headers["Access-Control-Allow-Origin"]  = "*"
        resp.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
        resp.headers["Access-Control-Allow-Headers"] = "Content-Type"
        return resp

    # ── helpers ───────────────────────────────────────────────
    def err(exc: ToolAPIError):
        return jsonify({"error": exc.body[:400], "tool": exc.tool}), (exc.status or 502)

    def not_configured(tool: str):
        return jsonify({"error": f"{tool} is not configured. Check .env file."}), 503

    def _int(v, lo, hi):
        try: return max(lo, min(hi, int(v)))
        except: return lo

    # ── UI ────────────────────────────────────────────────────
    @app.get("/")
    def index():
        return send_from_directory(str(STATIC_DIR), "chatbot.html")

    # ═════════════════════════════════════════════════════════
    # HEALTH — status of all connected tools
    # ═════════════════════════════════════════════════════════

    @app.get("/api/health")
    def health():
        tools = {}

        for name, client, label in [
            ("lm",      lm,      "LogicMonitor"),
            ("algosec", algosec, "AlgoSec"),
            ("kentik",  kentik,  "Kentik"),
        ]:
            if client is None:
                tools[name] = {"status": "not_configured", "label": label}
            else:
                try:
                    data = client.ping()
                    extra = data.get("total", data.get("devices", {}).get("total", "?"))
                    tools[name] = {"status": "connected", "label": label, "detail": str(extra)}
                except ToolAPIError as e:
                    tools[name] = {"status": "error", "label": label, "error": e.body[:100]}

        overall = "ok" if any(t["status"] == "connected" for t in tools.values()) else "degraded"
        return jsonify({"status": overall, "version": __version__, "tools": tools})

    # ═════════════════════════════════════════════════════════
    # LOGICMONITOR routes
    # ═════════════════════════════════════════════════════════

    @app.get("/api/lm/devices")
    def lm_devices():
        if not lm: return not_configured("LogicMonitor")
        try:
            return jsonify(lm.search_devices(
                filter=request.args.get("filter"),
                size=_int(request.args.get("size", 50), 1, 1000),
                fields=request.args.get("fields", "id,name,displayName,hostStatus,hostGroupIds"),
            ))
        except ToolAPIError as e: return err(e)

    @app.get("/api/lm/devices/<int:did>")
    def lm_device(did):
        if not lm: return not_configured("LogicMonitor")
        try: return jsonify(lm.get_device(did))
        except ToolAPIError as e: return err(e)

    @app.get("/api/lm/devices/<int:did>/instances")
    def lm_instances(did):
        if not lm: return not_configured("LogicMonitor")
        try:
            return jsonify(lm.get_device_instances(
                did,
                filter=request.args.get("filter"),
                size=_int(request.args.get("size", 100), 1, 1000),
            ))
        except ToolAPIError as e: return err(e)

    @app.get("/api/lm/instances/search")
    def lm_instances_search():
        if not lm: return not_configured("LogicMonitor")
        ifilter = request.args.get("instance_filter")
        if not ifilter:
            return jsonify({"error": "instance_filter is required"}), 400
        try:
            return jsonify(lm.search_instances_all_devices(
                ifilter,
                device_filter=request.args.get("device_filter"),
                max_devices=_int(request.args.get("max_devices", 30), 1, 100),
            ))
        except ToolAPIError as e: return err(e)

    @app.get("/api/lm/devices/<int:did>/datasources")
    def lm_datasources(did):
        if not lm: return not_configured("LogicMonitor")
        try:
            return jsonify(lm.get_device_datasources(did, size=_int(request.args.get("size", 50), 1, 1000)))
        except ToolAPIError as e: return err(e)

    @app.get("/api/lm/groups")
    def lm_groups():
        if not lm: return not_configured("LogicMonitor")
        try:
            return jsonify(lm.get_device_groups(
                filter=request.args.get("filter"),
                size=_int(request.args.get("size", 50), 1, 1000),
            ))
        except ToolAPIError as e: return err(e)

    @app.get("/api/lm/alerts")
    def lm_alerts():
        if not lm: return not_configured("LogicMonitor")
        try:
            return jsonify(lm.get_alerts(
                filter=request.args.get("filter"),
                size=_int(request.args.get("size", 30), 1, 1000),
            ))
        except ToolAPIError as e: return err(e)

    @app.get("/api/lm/collectors")
    def lm_collectors():
        if not lm: return not_configured("LogicMonitor")
        try:
            return jsonify(lm.get_collectors(size=_int(request.args.get("size", 20), 1, 100)))
        except ToolAPIError as e: return err(e)

    # ═════════════════════════════════════════════════════════
    # ALGOSEC routes
    # ═════════════════════════════════════════════════════════

    @app.get("/api/algosec/devices")
    def as_devices():
        if not algosec: return not_configured("AlgoSec")
        try:
            return jsonify(algosec.get_devices(size=_int(request.args.get("size", 50), 1, 500)))
        except ToolAPIError as e: return err(e)

    @app.get("/api/algosec/network_objects")
    def as_network_objects():
        if not algosec: return not_configured("AlgoSec")
        try:
            return jsonify(algosec.get_network_objects(
                search=request.args.get("search"),
                size=_int(request.args.get("size", 50), 1, 500),
            ))
        except ToolAPIError as e: return err(e)

    @app.get("/api/algosec/rules")
    def as_rules():
        if not algosec: return not_configured("AlgoSec")
        try:
            return jsonify(algosec.search_firewall_rules(
                src=request.args.get("src"),
                dst=request.args.get("dst"),
                service=request.args.get("service"),
                device=request.args.get("device"),
            ))
        except ToolAPIError as e: return err(e)

    @app.get("/api/algosec/simulate")
    def as_simulate():
        if not algosec: return not_configured("AlgoSec")
        src = request.args.get("src")
        dst = request.args.get("dst")
        if not src or not dst:
            return jsonify({"error": "src and dst are required"}), 400
        try:
            return jsonify(algosec.simulate_traffic(
                src, dst, service=request.args.get("service", "any")
            ))
        except ToolAPIError as e: return err(e)

    @app.get("/api/algosec/change_requests")
    def as_change_requests():
        if not algosec: return not_configured("AlgoSec")
        try:
            return jsonify(algosec.get_change_requests(
                status=request.args.get("status"),
                size=_int(request.args.get("size", 30), 1, 200),
            ))
        except ToolAPIError as e: return err(e)

    # ═════════════════════════════════════════════════════════
    # KENTIK routes
    # ═════════════════════════════════════════════════════════

    @app.get("/api/kentik/devices")
    def kt_devices():
        if not kentik: return not_configured("Kentik")
        try: return jsonify(kentik.get_devices())
        except ToolAPIError as e: return err(e)

    @app.get("/api/kentik/devices/<did>/interfaces")
    def kt_interfaces(did):
        if not kentik: return not_configured("Kentik")
        try: return jsonify(kentik.get_interfaces(did))
        except ToolAPIError as e: return err(e)

    @app.get("/api/kentik/alerts")
    def kt_alerts():
        if not kentik: return not_configured("Kentik")
        try:
            return jsonify(kentik.get_alerts(
                status=request.args.get("status", "active"),
                limit=_int(request.args.get("limit", 30), 1, 200),
            ))
        except ToolAPIError as e: return err(e)

    @app.get("/api/kentik/top_flows")
    def kt_top_flows():
        if not kentik: return not_configured("Kentik")
        try:
            return jsonify(kentik.get_top_flows(
                lookback_seconds=_int(request.args.get("lookback", 3600), 300, 86400),
                metric=request.args.get("metric", "bytes"),
                dimension=request.args.get("dimension", "IP_src"),
                limit=_int(request.args.get("limit", 20), 5, 100),
            ))
        except ToolAPIError as e: return err(e)

    @app.get("/api/kentik/sites")
    def kt_sites():
        if not kentik: return not_configured("Kentik")
        try: return jsonify(kentik.get_sites())
        except ToolAPIError as e: return err(e)

    @app.get("/api/kentik/plans")
    def kt_plans():
        if not kentik: return not_configured("Kentik")
        try: return jsonify(kentik.get_plans())
        except ToolAPIError as e: return err(e)

    return app


# ── entry point ───────────────────────────────────────────────────

def run() -> None:
    cfg = get_settings()
    app = create_app()

    print("\n╔══════════════════════════════════════╗")
    print("║         NMS OneView v1.0.0           ║")
    print("╚══════════════════════════════════════╝")

    for name, ready, label in [
        ("lm",      cfg.lm.is_ready,      "LogicMonitor"),
        ("algosec", cfg.algosec.is_ready,  "AlgoSec     "),
        ("kentik",  cfg.kentik.is_ready,   "Kentik       "),
    ]:
        icon = "✓" if ready else "✗"
        print(f"  {icon} {label}")

    print(f"\n  → http://localhost:{cfg.flask_port}\n")

    app.run(
        host=cfg.flask_host,
        port=cfg.flask_port,
        debug=not cfg.is_production,
        use_reloader=not cfg.is_production,
    )


if __name__ == "__main__":
    run()
