"""NMS OneView — unified multi-tool network management chatbot."""
__version__ = "1.0.0"
