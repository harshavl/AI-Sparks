"""
config.py
All tool credentials loaded from .env.
Each tool has an `enabled` flag — disabled tools show as
"not configured" in the UI without crashing the server.
"""
import os
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from dotenv import load_dotenv

for _p in [Path(__file__).parent, Path(__file__).parent.parent,
           Path(__file__).parent.parent.parent]:
    if (_p / ".env").exists():
        load_dotenv(_p / ".env")
        break


def _bool(val: str | None, default: bool = False) -> bool:
    return str(val or "").lower() in ("1", "true", "yes")


# ── per-tool config dataclasses ──────────────────────────────────

@dataclass
class LMConfig:
    enabled:      bool
    account:      str
    bearer_token: str
    api_version:  str = "v3"

    @property
    def base_url(self) -> str:
        return f"https://{self.account}.logicmonitor.com/santaba/rest"

    @property
    def version_header(self) -> str:
        return "3" if self.api_version == "v3" else "2"

    @property
    def is_ready(self) -> bool:
        return self.enabled and bool(self.account) and bool(self.bearer_token)


@dataclass
class AlgoSecConfig:
    enabled:  bool
    host:     str
    username: str
    password: str
    domain:   str = "Default"

    @property
    def is_ready(self) -> bool:
        return self.enabled and bool(self.host) and bool(self.username) and bool(self.password)


@dataclass
class KentikConfig:
    enabled:   bool
    email:     str
    api_token: str
    api_url:   str = "https://api.kentik.com/api/v5"

    @property
    def is_ready(self) -> bool:
        return self.enabled and bool(self.email) and bool(self.api_token)


# ── top-level settings ────────────────────────────────────────────

@dataclass
class Settings:
    flask_host: str
    flask_port: int
    flask_env:  str
    lm:         LMConfig
    algosec:    AlgoSecConfig
    kentik:     KentikConfig

    @property
    def is_production(self) -> bool:
        return self.flask_env.lower() == "production"


@lru_cache
def get_settings() -> Settings:
    return Settings(
        flask_host = os.getenv("FLASK_HOST", "0.0.0.0"),
        flask_port = int(os.getenv("FLASK_PORT", "8000")),
        flask_env  = os.getenv("FLASK_ENV", "development"),
        lm = LMConfig(
            enabled      = _bool(os.getenv("LM_ENABLED"), True),
            account      = os.getenv("LM_ACCOUNT", ""),
            bearer_token = os.getenv("LM_BEARER_TOKEN", ""),
            api_version  = os.getenv("LM_API_VERSION", "v3"),
        ),
        algosec = AlgoSecConfig(
            enabled  = _bool(os.getenv("ALGOSEC_ENABLED"), True),
            host     = os.getenv("ALGOSEC_HOST", ""),
            username = os.getenv("ALGOSEC_USERNAME", ""),
            password = os.getenv("ALGOSEC_PASSWORD", ""),
            domain   = os.getenv("ALGOSEC_DOMAIN", "Default"),
        ),
        kentik = KentikConfig(
            enabled   = _bool(os.getenv("KENTIK_ENABLED"), True),
            email     = os.getenv("KENTIK_EMAIL", ""),
            api_token = os.getenv("KENTIK_API_TOKEN", ""),
            api_url   = os.getenv("KENTIK_API_URL", "https://api.kentik.com/api/v5"),
        ),
    )
