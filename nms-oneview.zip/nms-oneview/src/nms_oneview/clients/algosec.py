"""
clients/algosec.py
AlgoSec FireFlow / BusinessFlow REST API client.

AlgoSec uses session-cookie auth:
  POST /php/login.php  →  cookie stored in session
  GET  /api/v1/...     →  uses cookie automatically

Docs: https://api.algosec.com/algosec-api/
"""
from __future__ import annotations
import logging
from nms_oneview.clients.base import BaseClient, ToolAPIError
from nms_oneview.config import AlgoSecConfig

log = logging.getLogger(__name__)


class AlgoSecClient(BaseClient):
    TOOL_NAME = "AlgoSec"

    def __init__(self, cfg: AlgoSecConfig) -> None:
        super().__init__()
        self._base     = cfg.host.rstrip("/")
        self._username = cfg.username
        self._password = cfg.password
        self._domain   = cfg.domain
        self._authed   = False

    # ── auth ──────────────────────────────────────────────────
    def _ensure_auth(self) -> None:
        """Authenticate once; session cookie handles subsequent calls."""
        if self._authed:
            return
        url = f"{self._base}/php/login.php"
        try:
            r = self._session.post(url, json={
                "username": self._username,
                "password": self._password,
                "domain":   self._domain,
            }, timeout=30)
            if not r.ok:
                raise ToolAPIError(r.status_code, r.text, self.TOOL_NAME)
        except Exception as e:
            if not isinstance(e, ToolAPIError):
                raise ToolAPIError(0, str(e), self.TOOL_NAME)
            raise
        self._authed = True
        log.info("AlgoSec authenticated as %s", self._username)

    def _asec(self, path: str, params: dict | None = None) -> dict:
        self._ensure_auth()
        return self._get(self._base + path, params)

    # ── connectivity ──────────────────────────────────────────
    def ping(self) -> dict:
        """Verify auth works — fetch network objects list."""
        return self._asec("/api/v1/network_objects", {"max": 1})

    # ── network objects ───────────────────────────────────────
    def get_network_objects(self, search: str | None = None,
                             size: int = 50) -> dict:
        params = {"max": size}
        if search:
            params["search"] = search
        return self._asec("/api/v1/network_objects", params)

    # ── firewall rules ────────────────────────────────────────
    def search_firewall_rules(self, src: str | None = None,
                               dst: str | None = None,
                               service: str | None = None,
                               device: str | None = None) -> dict:
        params = {}
        if src:     params["source"]      = src
        if dst:     params["destination"] = dst
        if service: params["service"]     = service
        if device:  params["device"]      = device
        return self._asec("/api/v1/firewall_rules", params)

    # ── traffic simulation (path analysis) ───────────────────
    def simulate_traffic(self, src: str, dst: str,
                          service: str = "any") -> dict:
        self._ensure_auth()
        return self._post(self._base + "/api/v1/traffic_simulation_queries", json={
            "sources":      [src],
            "destinations": [dst],
            "services":     [service],
        })

    # ── policy analysis ───────────────────────────────────────
    def get_policy_analysis(self, application: str) -> dict:
        return self._asec(f"/api/v1/applications/{application}/risks")

    # ── change requests ───────────────────────────────────────
    def get_change_requests(self, status: str | None = None,
                             size: int = 30) -> dict:
        params: dict = {"max": size}
        if status:
            params["status"] = status
        return self._asec("/api/v1/change_requests", params)

    # ── devices / firewalls ───────────────────────────────────
    def get_devices(self, size: int = 50) -> dict:
        return self._asec("/api/v1/devices", {"max": size})
