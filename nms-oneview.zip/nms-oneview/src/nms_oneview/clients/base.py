"""
clients/base.py
Shared base for all tool clients.
Provides a requests Session with retry logic and a common _get() method.
"""
from __future__ import annotations
import logging
from typing import Any
import requests
from requests import Session
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

log = logging.getLogger(__name__)


class ToolAPIError(Exception):
    """Raised when a tool API returns a non-2xx response."""
    def __init__(self, status: int, body: str, tool: str = "") -> None:
        self.status = status
        self.body   = body
        self.tool   = tool
        super().__init__(f"[{tool}] API {status}: {body[:300]}")


class BaseClient:
    """Shared HTTP session with retry + pooling."""

    TOOL_NAME = "Unknown"

    def __init__(self) -> None:
        self._session = Session()
        retry = Retry(
            total=3, backoff_factor=0.5,
            status_forcelist=[500, 502, 503, 504],
            allowed_methods=["GET", "POST"],
        )
        adapter = HTTPAdapter(
            max_retries=retry,
            pool_connections=5,
            pool_maxsize=10,
        )
        self._session.mount("https://", adapter)
        self._session.mount("http://",  adapter)

    def _get(self, url: str, params: dict | None = None,
             headers: dict | None = None) -> dict:
        clean = {k: v for k, v in (params or {}).items() if v is not None}
        log.debug("%s GET %s params=%s", self.TOOL_NAME, url, clean)
        try:
            r = self._session.get(url, params=clean,
                                  headers=headers, timeout=30)
        except requests.exceptions.ConnectionError as e:
            raise ToolAPIError(0, f"Connection error: {e}", self.TOOL_NAME)
        except requests.exceptions.Timeout as e:
            raise ToolAPIError(0, f"Timeout: {e}", self.TOOL_NAME)
        except requests.exceptions.RequestException as e:
            raise ToolAPIError(0, f"Request failed: {e}", self.TOOL_NAME)
        if not r.ok:
            raise ToolAPIError(r.status_code, r.text, self.TOOL_NAME)
        return r.json()

    def _post(self, url: str, json: dict | None = None,
              headers: dict | None = None) -> dict:
        log.debug("%s POST %s", self.TOOL_NAME, url)
        try:
            r = self._session.post(url, json=json,
                                   headers=headers, timeout=30)
        except requests.exceptions.RequestException as e:
            raise ToolAPIError(0, str(e), self.TOOL_NAME)
        if not r.ok:
            raise ToolAPIError(r.status_code, r.text, self.TOOL_NAME)
        return r.json()

    def close(self) -> None:
        self._session.close()
