"""
clients/kentik.py
Kentik Network Observability API client.

Auth: X-CH-Auth-Email + X-CH-Auth-API-Token headers on every request.
Docs: https://kb.kentik.com/v0/Bd06.htm
"""
from __future__ import annotations
import logging
from nms_oneview.clients.base import BaseClient, ToolAPIError
from nms_oneview.config import KentikConfig

log = logging.getLogger(__name__)


class KentikClient(BaseClient):
    TOOL_NAME = "Kentik"

    def __init__(self, cfg: KentikConfig) -> None:
        super().__init__()
        self._base = cfg.api_url.rstrip("/")
        self._session.headers.update({
            "X-CH-Auth-Email":    cfg.email,
            "X-CH-Auth-API-Token": cfg.api_token,
            "Content-Type":       "application/json",
        })

    def _kt(self, path: str, params: dict | None = None) -> dict:
        return self._get(self._base + path, params)

    def _kt_post(self, path: str, json: dict | None = None) -> dict:
        return self._post(self._base + path, json=json)

    # ── connectivity ──────────────────────────────────────────
    def ping(self) -> dict:
        """Verify connectivity — list devices (1 result)."""
        return self._kt("/device", {"pageSize": 1})

    # ── devices ───────────────────────────────────────────────
    def get_devices(self) -> dict:
        return self._kt("/device")

    def get_device(self, device_id: str) -> dict:
        return self._kt(f"/device/{device_id}")

    # ── interfaces ────────────────────────────────────────────
    def get_interfaces(self, device_id: str) -> dict:
        return self._kt(f"/device/{device_id}/interface")

    # ── top talkers / traffic ─────────────────────────────────
    def get_top_flows(self, lookback_seconds: int = 3600,
                       metric: str = "bytes",
                       dimension: str = "IP_src",
                       limit: int = 20) -> dict:
        """Run a data-explorer query for top flows."""
        return self._kt_post("/query/topxdata", json={
            "queries": [{
                "query": {
                    "dimension":       [dimension],
                    "metric":          [metric],
                    "time_range":      f"Last {lookback_seconds // 60} minutes",
                    "lookback_seconds": lookback_seconds,
                    "limit":           limit,
                    "fast_data":       "Auto",
                    "aggregation":     {"type": "default", "agg_func": "sum", "raw_data": False},
                },
                "id": "oneview_top_flows",
            }]
        })

    # ── alerts ────────────────────────────────────────────────
    def get_alerts(self, status: str = "active", limit: int = 30) -> dict:
        return self._kt("/alerts", {"status": status, "limit": limit})

    def get_alert_policies(self) -> dict:
        return self._kt("/alerts/policies")

    # ── sites ─────────────────────────────────────────────────
    def get_sites(self) -> dict:
        return self._kt("/sites")

    # ── saved queries ─────────────────────────────────────────
    def get_saved_queries(self) -> dict:
        return self._kt("/saved-queries")

    # ── plans / capacity ─────────────────────────────────────
    def get_plans(self) -> dict:
        return self._kt("/plans")
