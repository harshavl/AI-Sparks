"""
clients/logicmonitor.py
LogicMonitor REST API client (requests-based).
"""
from __future__ import annotations
from nms_oneview.clients.base import BaseClient, ToolAPIError
from nms_oneview.config import LMConfig


class LogicMonitorClient(BaseClient):
    TOOL_NAME = "LogicMonitor"

    def __init__(self, cfg: LMConfig) -> None:
        super().__init__()
        self._base = cfg.base_url
        self._session.headers.update({
            "Authorization": f"Bearer {cfg.bearer_token}",
            "Content-Type":  "application/json",
            "X-Version":     cfg.version_header,
        })

    def _lm(self, path: str, params: dict | None = None) -> dict:
        return self._get(self._base + path, params)

    # ── connectivity ──────────────────────────────────────────
    def ping(self) -> dict:
        return self._lm("/device/devices", {"size": 1, "fields": "id,name"})

    # ── devices ───────────────────────────────────────────────
    def search_devices(self, filter: str | None = None, size: int = 50,
                       fields: str = "id,name,displayName,hostStatus,hostGroupIds") -> dict:
        return self._lm("/device/devices", {"filter": filter, "size": size, "fields": fields})

    def get_device(self, device_id: int) -> dict:
        return self._lm(f"/device/devices/{device_id}")

    # ── instances ─────────────────────────────────────────────
    def get_device_instances(self, device_id: int, filter: str | None = None,
                              size: int = 100) -> dict:
        return self._lm(f"/device/devices/{device_id}/instances",
                        {"filter": filter, "size": size,
                         "fields": "id,name,displayName,dataSourceName"})

    def search_instances_all_devices(self, instance_filter: str,
                                      device_filter: str | None = None,
                                      max_devices: int = 30) -> dict:
        devs = self.search_devices(filter=device_filter, size=max_devices,
                                   fields="id,name,displayName").get("items", [])
        matches = []
        for dev in devs:
            try:
                r = self.get_device_instances(dev["id"], filter=instance_filter)
                if r.get("items"):
                    matches.append({"device": dev, "instances": r["items"]})
            except ToolAPIError:
                pass
        return {"devices_searched": len(devs),
                "devices_with_matches": len(matches), "matches": matches}

    # ── groups / alerts / collectors ──────────────────────────
    def get_device_groups(self, filter: str | None = None, size: int = 50) -> dict:
        return self._lm("/device/groups",
                        {"filter": filter, "size": size,
                         "fields": "id,name,fullPath,numOfHosts"})

    def get_alerts(self, filter: str | None = None, size: int = 30) -> dict:
        return self._lm("/alert/alerts",
                        {"filter": filter, "size": size,
                         "fields": "id,resourceTemplateName,instanceName,severity,startEpoch,message,resourceId"})

    def get_collectors(self, size: int = 20) -> dict:
        return self._lm("/setting/collector/collectors",
                        {"size": size, "fields": "id,hostname,status,description,platform"})

    def get_device_datasources(self, device_id: int, size: int = 50) -> dict:
        return self._lm(f"/device/devices/{device_id}/devicedatasources",
                        {"size": size, "fields": "id,dataSourceName,dataSourceType,instanceNumber"})
